const MatchFixture = require('../models/MatchFixture');

exports.createMatchFixture = async (req, res) => {
  try {
    const matchFixture = new MatchFixture(req.body);
    await matchFixture.save();
    res.status(201).json(matchFixture);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.getAllMatchFixtures = async (req, res) => {
  try {
    const matchFixtures = await MatchFixture.find()
      .populate('home_team_id')
      .populate('away_team_id')
      .populate('tournament_id');
    res.json(matchFixtures);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getMatchFixtureById = async (req, res) => {
  try {
    const matchFixture = await MatchFixture.findById(req.params.id)
      .populate('home_team_id')
      .populate('away_team_id')
      .populate('tournament_id');
    if (!matchFixture) return res.status(404).json({ message: 'Match fixture not found' });
    res.json(matchFixture);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.updateMatchFixture = async (req, res) => {
  try {
    const matchFixture = await MatchFixture.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!matchFixture) return res.status(404).json({ message: 'Match fixture not found' });
    res.json(matchFixture);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.deleteMatchFixture = async (req, res) => {
  try {
    const matchFixture = await MatchFixture.findByIdAndDelete(req.params.id);
    if (!matchFixture) return res.status(404).json({ message: 'Match fixture not found' });
    res.json({ message: 'Match fixture deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
