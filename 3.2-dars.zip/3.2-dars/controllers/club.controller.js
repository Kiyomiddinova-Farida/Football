const FootballClub = require('../models/FootballClub');

exports.createClub = async (req, res) => {
  try {
    const club = new FootballClub(req.body);
    await club.save();
    res.status(201).json(club);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.getAllClubs = async (req, res) => {
  try {
    const clubs = await FootballClub.find();
    res.json(clubs);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getClubById = async (req, res) => {
  try {
    const club = await FootballClub.findById(req.params.id);
    if (!club) return res.status(404).json({ message: 'Club not found' });
    res.json(club);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.updateClub = async (req, res) => {
  try {
    const club = await FootballClub.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!club) return res.status(404).json({ message: 'Club not found' });
    res.json(club);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.deleteClub = async (req, res) => {
  try {
    const club = await FootballClub.findByIdAndDelete(req.params.id);
    if (!club) return res.status(404).json({ message: 'Club not found' });
    res.json({ message: 'Club deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};