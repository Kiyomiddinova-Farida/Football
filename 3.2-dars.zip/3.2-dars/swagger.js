const swaggerJsdoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');

const swaggerOptions = {
  definition: {
    openapi: '3.0.0', 
    info: {
      title: 'Football Game API',
      version: '1.0.0',
      description: 'API documentation for the Football Game application',
      contact: {
        name: 'Your Name',
        url: 'https://yourwebsite.com',
        email: 'youremail@example.com',
      },
    },
    servers: [
      {
        url: 'http://localhost:3000/api', 
      },
    ],
  },
  apis: ['./routes/*.js'], 
};

const swaggerDocs = swaggerJsdoc(swaggerOptions);

module.exports = swaggerDocs;
