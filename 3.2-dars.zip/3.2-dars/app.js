const express = require('express');
const connectDB = require('./config/db');
const dotenv = require('dotenv');
const swaggerDocs = require('./swagger');
const swaggerUi = require('swagger-ui-express');
const cors = require('cors');
const tournamentRoutes = require('./routes/tournament.routes');
const matchFixtureRoutes = require('./routes/match.routes');
const teamRoutes = require('./routes/team.routes');
const playerRoutes = require('./routes/player.routes');
const footballClubRoutes = require('./routes/club.routes');

dotenv.config();

connectDB();
const app = express();

app.use(express.json()); 
app.use(cors()); 

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocs));

app.use('/api/tournaments', tournamentRoutes);
app.use('/api/match-fixtures', matchFixtureRoutes);
app.use('/api/teams', teamRoutes);
app.use('/api/players', playerRoutes);
app.use('/api/football-clubs', footballClubRoutes);


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});