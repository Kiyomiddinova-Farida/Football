const mongoose = require('mongoose');

const matchFixtureSchema = new mongoose.Schema({
    match_date: {
        type: Date,
        required: true
    },
    venue: {
        type: String,
        required: true
    },
    home_team_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Team',
        required: true
    },
    away_team_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Team', required: true
    },
    home_score: {
        type: Number,
        default: 0
    },
    away_score: {
        type: Number, default: 0
    },
    tournament_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Tournament', required: true
    },
    match_status: {
        type: String,
        default: 'scheduled'
    },
});

module.exports = mongoose.model('MatchFixture', matchFixtureSchema);
