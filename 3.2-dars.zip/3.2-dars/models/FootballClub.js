const mongoose = require('mongoose');

const footballClubSchema = new mongoose.Schema({
    club_name: {
        type: String,
        required: true,
        unique: true
    },
    city: {
        type: String,
        required: true
    },
    country: {
        type: String,
        required: true
    },
    founded_year: {
        type: Number
    }
});

module.exports = mongoose.model('FootballClub', footballClubSchema);