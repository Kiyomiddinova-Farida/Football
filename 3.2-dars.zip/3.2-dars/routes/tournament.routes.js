const express = require('express');
const tournamentController = require('../controllers/tournament.controller');
const authMiddleware = require('../middleware/authMiddleware');
const router = express.Router();

/**
 * @swagger
 * /tournaments:
 *   post:
 *     tags:
 *       - Tournament
 *     summary: Create a new tournament
 *     operationId: createTournament
 *     description: Creates a new tournament and adds it to the database
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               startDate:
 *                 type: string
 *                 format: date
 *               endDate:
 *                 type: string
 *                 format: date
 *               location:
 *                 type: string
 *     responses:
 *       201:
 *         description: Tournament created successfully
 *       400:
 *         description: Bad request
 */
router.post("/", tournamentController.createTournament);

/**
 * @swagger
 * /tournaments:
 *   get:
 *     tags:
 *       - Tournament
 *     summary: Get all tournaments
 *     operationId: getAllTournaments
 *     description: Retrieves a list of all tournaments from the database
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: A list of tournaments
 *       401:
 *         description: Unauthorized - Authentication failed
 */
router.get('/', authMiddleware, tournamentController.getAllTournaments);

/**
 * @swagger
 * /tournaments/{id}:
 *   get:
 *     tags:
 *       - Tournament
 *     summary: Get a tournament by ID
 *     operationId: getTournamentById
 *     description: Retrieves a specific tournament by its ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the tournament to retrieve
 *         schema:
 *           type: string
 *           example: 64f14c9e1a5b3f001c9e821a
 *     responses:
 *       200:
 *         description: A tournament object
 *       404:
 *         description: Tournament not found
 */
router.get("/:id", tournamentController.getTournamentById);

/**
 * @swagger
 * /tournaments/{id}:
 *   put:
 *     tags:
 *       - Tournament
 *     summary: Update a tournament's details
 *     operationId: updateTournament
 *     description: Updates a tournament's information by its ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the tournament to update
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               startDate:
 *                 type: string
 *                 format: date
 *               endDate:
 *                 type: string
 *                 format: date
 *               location:
 *                 type: string
 *     responses:
 *       200:
 *         description: Tournament updated successfully
 *       400:
 *         description: Bad request
 *       404:
 *         description: Tournament not found
 */
router.put("/:id", tournamentController.updateTournament);

/**
 * @swagger
 * /tournaments/{id}:
 *   delete:
 *     tags:
 *       - Tournament
 *     summary: Delete a tournament
 *     operationId: deleteTournament
 *     description: Deletes a tournament by its ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the tournament to delete
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Tournament deleted successfully
 *       404:
 *         description: Tournament not found
 */
router.delete("/:id", tournamentController.deleteTournament);

module.exports = router;