const express = require('express');
const router = express.Router();
const groupController = require('../controllers/group.controller');

/**
 * @swagger
 * tags:
 *   name: Groups
 *   description: Group management endpoints
 */

/**
 * @swagger
 * /groups:
 *   post:
 *     summary: Create a new group
 *     tags: [Groups]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *             properties:
 *               name:
 *                 type: string
 *                 example: Group A
 *               description:
 *                 type: string
 *                 example: This is the first qualifying group
 *               members:
 *                 type: array
 *                 items:
 *                   type: string
 *                 example: ["Team1", "Team2"]
 *     responses:
 *       201:
 *         description: Group created successfully
 *       400:
 *         description: Bad request
 */
router.post('/', groupController.createGroup);

/**
 * @swagger
 * /groups:
 *   get:
 *     summary: Get all groups
 *     tags: [Groups]
 *     responses:
 *       200:
 *         description: A list of groups
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                   name:
 *                     type: string
 *                   description:
 *                     type: string
 *                   members:
 *                     type: array
 *                     items:
 *                       type: string
 */
router.get('/', groupController.getAllGroups);

/**
 * @swagger
 * /groups/{id}:
 *   get:
 *     summary: Get a group by ID
 *     tags: [Groups]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the group to retrieve
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: A group object
 *       404:
 *         description: Group not found
 */
router.get('/:id', groupController.getGroupById);

/**
 * @swagger
 * /groups/{id}:
 *   put:
 *     summary: Update a group
 *     tags: [Groups]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the group to update
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: Group B
 *               description:
 *                 type: string
 *                 example: Updated description for the group
 *               members:
 *                 type: array
 *                 items:
 *                   type: string
 *                 example: ["Team3", "Team4"]
 *     responses:
 *       200:
 *         description: Group updated successfully
 *       400:
 *         description: Bad request
 *       404:
 *         description: Group not found
 */
router.put('/:id', groupController.updateGroup);

/**
 * @swagger
 * /groups/{id}:
 *   delete:
 *     summary: Delete a group
 *     tags: [Groups]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the group to delete
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Group deleted successfully
 *       404:
 *         description: Group not found
 */
router.delete('/:id', groupController.deleteGroup);

module.exports = router;