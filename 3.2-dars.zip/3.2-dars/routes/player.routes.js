const express = require('express');
const playerController = require('../controllers/player.controller');
const authMiddleware = require('../middleware/authMiddleware');
const router = express.Router();

/**
 * @swagger
 * /players:
 *   post:
 *     tags:
 *       - Player
 *     summary: Create a new player
 *     operationId: createPlayer
 *     description: Creates a new player and adds them to the database
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: Lionel Messi
 *               position:
 *                 type: string
 *                 example: Forward
 *               team:
 *                 type: string
 *                 example: Inter Miami CF
 *               nationality:
 *                 type: string
 *                 example: Argentina
 *     responses:
 *       201:
 *         description: Player created successfully
 *       400:
 *         description: Bad request
 *       401:
 *         description: Unauthorized - Authentication failed
 */
router.post('/', authMiddleware, playerController.createPlayer);

/**
 * @swagger
 * /players:
 *   get:
 *     tags:
 *       - Player
 *     summary: Get all players
 *     operationId: getAllPlayers
 *     description: Retrieves a list of all players in the database
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: A list of players
 *       401:
 *         description: Unauthorized - Authentication failed
 */
router.get('/', authMiddleware, playerController.getAllPlayers);

/**
 * @swagger
 * /players/{id}:
 *   get:
 *     tags:
 *       - Player
 *     summary: Get a player by ID
 *     operationId: getPlayerById
 *     description: Retrieves a player based on the provided ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the player to retrieve
 *         schema:
 *           type: string
 *           example: 64e9c5a7f132e8001c23b9d2
 *     responses:
 *       200:
 *         description: A player object
 *       404:
 *         description: Player not found
 */
router.get('/:id', playerController.getPlayerById);

/**
 * @swagger
 * /players/{id}:
 *   put:
 *     tags:
 *       - Player
 *     summary: Update a player's details
 *     operationId: updatePlayer
 *     description: Updates a player's information by their ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the player to update
 *         schema:
 *           type: string
 *           example: 64e9c5a7f132e8001c23b9d2
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: Cristiano Ronaldo
 *               position:
 *                 type: string
 *                 example: Forward
 *               team:
 *                 type: string
 *                 example: Al Nassr
 *               nationality:
 *                 type: string
 *                 example: Portugal
 *     responses:
 *       200:
 *         description: Player updated successfully
 *       400:
 *         description: Bad request
 *       404:
 *         description: Player not found
 */
router.put('/:id', playerController.updatePlayer);

/**
 * @swagger
 * /players/{id}:
 *   delete:
 *     tags:
 *       - Player
 *     summary: Delete a player
 *     operationId: deletePlayer
 *     description: Deletes a player from the database by their ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the player to delete
 *         schema:
 *           type: string
 *           example: 64e9c5a7f132e8001c23b9d2
 *     responses:
 *       200:
 *         description: Player deleted successfully
 *       404:
 *         description: Player not found
 */
router.delete('/:id', playerController.deletePlayer);

module.exports = router;