const express = require('express');
const router = express.Router();
const teamController = require('../controllers/team.controller');

/**
 * @swagger
 * /teams:
 *   post:
 *     tags:
 *       - Team
 *     summary: Create a new team
 *     operationId: createTeam
 *     description: Creates a new team and adds it to the database
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: Real Madrid
 *               coach:
 *                 type: string
 *                 example: Carlo Ancelotti
 *               city:
 *                 type: string
 *                 example: Madrid
 *     responses:
 *       201:
 *         description: Team created successfully
 *       400:
 *         description: Bad request
 */
router.post('/', teamController.createTeam);

/**
 * @swagger
 * /teams:
 *   get:
 *     tags:
 *       - Team
 *     summary: Get all teams
 *     operationId: getAllTeams
 *     description: Retrieves a list of all teams in the database
 *     responses:
 *       200:
 *         description: A list of teams
 */
router.get('/', teamController.getAllTeams);

/**
 * @swagger
 * /teams/{id}:
 *   get:
 *     tags:
 *       - Team
 *     summary: Get a team by ID
 *     operationId: getTeamById
 *     description: Retrieves a team based on the provided ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the team to retrieve
 *         schema:
 *           type: string
 *           example: 64f14c9e1a5b3f001c9e821a
 *     responses:
 *       200:
 *         description: A team object
 *       404:
 *         description: Team not found
 */
router.get('/:id', teamController.getTeamById);

/**
 * @swagger
 * /teams/{id}:
 *   put:
 *     tags:
 *       - Team
 *     summary: Update a team's details
 *     operationId: updateTeam
 *     description: Updates a team's information by their ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the team to update
 *         schema:
 *           type: string
 *           example: 64f14c9e1a5b3f001c9e821a
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: Barcelona
 *               coach:
 *                 type: string
 *                 example: Xavi Hernandez
 *               city:
 *                 type: string
 *                 example: Barcelona
 *     responses:
 *       200:
 *         description: Team updated successfully
 *       400:
 *         description: Bad request
 *       404:
 *         description: Team not found
 */
router.put('/:id', teamController.updateTeam);

/**
 * @swagger
 * /teams/{id}:
 *   delete:
 *     tags:
 *       - Team
 *     summary: Delete a team
 *     operationId: deleteTeam
 *     description: Deletes a team from the database by its ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the team to delete
 *         schema:
 *           type: string
 *           example: 64f14c9e1a5b3f001c9e821a
 *     responses:
 *       200:
 *         description: Team deleted successfully
 *       404:
 *         description: Team not found
 */
router.delete('/:id', teamController.deleteTeam);

module.exports = router;