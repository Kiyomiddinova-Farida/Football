const express = require('express');
const router = express.Router();
const matchFixtureController = require('../controllers/match.controller');

/**
 * @swagger
 * tags:
 *   name: Match Fixtures
 *   description: Match fixture management endpoints
 */

/**
 * @swagger
 * /match-fixtures:
 *   post:
 *     summary: Create a new match fixture
 *     tags: [Match Fixtures]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - team1
 *               - team2
 *               - date
 *               - venue
 *             properties:
 *               team1:
 *                 type: string
 *                 example: Team Alpha
 *               team2:
 *                 type: string
 *                 example: Team Beta
 *               date:
 *                 type: string
 *                 format: date-time
 *                 example: 2025-04-20T15:30:00Z
 *               venue:
 *                 type: string
 *                 example: National Stadium
 *     responses:
 *       201:
 *         description: Match fixture created successfully
 *       400:
 *         description: Bad request
 */
router.post('/', matchFixtureController.createMatchFixture);

/**
 * @swagger
 * /match-fixtures:
 *   get:
 *     summary: Get all match fixtures
 *     tags: [Match Fixtures]
 *     responses:
 *       200:
 *         description: A list of match fixtures
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                   team1:
 *                     type: string
 *                   team2:
 *                     type: string
 *                   date:
 *                     type: string
 *                   venue:
 *                     type: string
 */
router.get('/', matchFixtureController.getAllMatchFixtures);

/**
 * @swagger
 * /match-fixtures/{id}:
 *   get:
 *     summary: Get a match fixture by its ID
 *     tags: [Match Fixtures]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the match fixture to retrieve
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: A match fixture object
 *       404:
 *         description: Match fixture not found
 */
router.get('/:id', matchFixtureController.getMatchFixtureById);

/**
 * @swagger
 * /match-fixtures/{id}:
 *   put:
 *     summary: Update a match fixture
 *     tags: [Match Fixtures]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the match fixture to update
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               team1:
 *                 type: string
 *                 example: Updated Team A
 *               team2:
 *                 type: string
 *                 example: Updated Team B
 *               date:
 *                 type: string
 *                 format: date-time
 *                 example: 2025-05-01T18:00:00Z
 *               venue:
 *                 type: string
 *                 example: Olympic Arena
 *     responses:
 *       200:
 *         description: Match fixture updated successfully
 *       400:
 *         description: Bad request
 *       404:
 *         description: Match fixture not found
 */
router.put('/:id', matchFixtureController.updateMatchFixture);

/**
 * @swagger
 * /match-fixtures/{id}:
 *   delete:
 *     summary: Delete a match fixture
 *     tags: [Match Fixtures]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the match fixture to delete
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Match fixture deleted successfully
 *       404:
 *         description: Match fixture not found
 */
router.delete('/:id', matchFixtureController.deleteMatchFixture);

module.exports = router;