const express = require('express');
const router = express.Router();
const clubController = require('../controllers/club.controller');

/**
 * @swagger
 * tags:
 *   name: Clubs
 *   description: Club management endpoints
 */

/**
 * @swagger
 * /clubs:
 *   post:
 *     summary: Create a new club
 *     tags: [Clubs]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *               - location
 *             properties:
 *               name:
 *                 type: string
 *                 example: Real Madrid
 *               location:
 *                 type: string
 *                 example: Madrid, Spain
 *               description:
 *                 type: string
 *                 example: One of the most successful football clubs in the world.
 *     responses:
 *       201:
 *         description: Club created successfully
 *       400:
 *         description: Bad request
 */
router.post('/', clubController.createClub);

/**
 * @swagger
 * /clubs:
 *   get:
 *     summary: Get all clubs
 *     tags: [Clubs]
 *     responses:
 *       200:
 *         description: A list of clubs
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                   name:
 *                     type: string
 *                   location:
 *                     type: string
 *                   description:
 *                     type: string
 */
router.get('/', clubController.getAllClubs);

/**
 * @swagger
 * /clubs/{id}:
 *   get:
 *     summary: Get a club by ID
 *     tags: [Clubs]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: The ID of the club to retrieve
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Club found
 *       404:
 *         description: Club not found
 */
router.get('/:id', clubController.getClubById);

/**
 * @swagger
 * /clubs/{id}:
 *   put:
 *     summary: Update a club
 *     tags: [Clubs]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: The ID of the club to update
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: FC Barcelona
 *               location:
 *                 type: string
 *                 example: Barcelona, Spain
 *               description:
 *                 type: string
 *                 example: Historic Spanish football club.
 *     responses:
 *       200:
 *         description: Club updated successfully
 *       400:
 *         description: Bad request
 *       404:
 *         description: Club not found
 */
router.put('/:id', clubController.updateClub);

/**
 * @swagger
 * /clubs/{id}:
 *   delete:
 *     summary: Delete a club
 *     tags: [Clubs]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: The ID of the club to delete
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Club deleted successfully
 *       404:
 *         description: Club not found
 */
router.delete('/:id', clubController.deleteClub);

module.exports = router;